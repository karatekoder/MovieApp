﻿using System;
using System.Collections.Generic;

namespace MovieApp.Models
{
    public partial class AdminCode
    {
        public string Code { get; set; }
    }
}
