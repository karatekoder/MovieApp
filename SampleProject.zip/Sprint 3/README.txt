Michael Kariuki - INFO2300
Use the it7.sql file in SSMS (SQL Server Management Studio) to create the database
When using SSMS, Server Type should be set to "Database Engine" and Server name should be "(LocalDb)\MSSQLLocalDB". Authentication is Windows Authentication
Please replace "FILENAME = " path with one appropriate for your local machine

Open the MovieApp.sln file in Visual Studio 2017 (or later) and run the project
 

Use password: jamdSecret to make oneself an admin
This will unlock admin functionalities like CRUD on movies
Users may only register one rating per movie
Movie listing page will reorganize itself to order by popularity
